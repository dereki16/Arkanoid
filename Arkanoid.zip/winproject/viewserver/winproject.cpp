#include "ground.h"
#include <vector>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define _USE_MATH_DEFINES
#include <math.h>


#define MAX_LOADSTRING 1000
// Globale Variablen:
HINSTANCE hInst;								// Aktuelle Instanz
TCHAR szTitle[MAX_LOADSTRING];					// Titelleistentext
TCHAR szWindowClass[MAX_LOADSTRING];			// Klassenname des Hauptfensters
HFONT editfont;
HWND hMain = NULL;
//-----------------------
static char MainWin[] = "MainWin";

LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);
void draw_line(HDC DC, int x, int y, int a, int b, int red, int green, int blue, int width);
void draw_text(HDC DC, char text[], int x, int y, int r, int g, int b)
{
	COLORREF rgb = RGB(r, g, b);
	SetTextColor(DC, rgb);
	SetBkMode(DC, TRANSPARENT);
	TextOut(DC, x, y, text, strlen(text));
}

HBRUSH  hWinCol = CreateSolidBrush(RGB(180, 180, 180));

HWND g_hwnd=NULL;

int dx = 0, dy = 0;
int bx = 0, by = 0;
int mx = 0, ex = 0;
int bspeed = 10;
int counter = 5;
bool restart = false;

struct Ball
{
	int x, y, r;
	int dx, dy;
	int dir_x, dir_y;

	void update()
	{
		x += dx;
		y += dy;
	}

	void draw(HDC dc)
	{
		draw_line(dc, x + dir_x, y + dir_y, x + dir_x, y + dir_y, 255, 0, 0, r);
	}
} ball;

struct Brick
{
	int x, y;
	int width, height;
	bool exists;
	int r, g, b;

	void draw(HDC dc)
	{
		draw_line(dc, x, y, x + width, y, r, g, b, height);
	}

	bool collidesWith(Ball& b)
	{
		if (b.x > x && b.x < x + width &&
			b.y > y - (height / 2.0f) && b.y < y + (height / 2.0f))
		{
			return true;
		}
		return false;
	}
};

struct Paddle
{
	int x, y;
	int dx;
	int width, height;
	int r;

	void draw(HDC dc)
	{
		draw_line(dc, mx - 20, y, mx + 20, y, 0, 0, 255, r);
	}

	void update()
	{
		x += mx;
	}

} paddle;

std::vector<Brick*> bricks; //<-- like Java's ArrayList class

//timer:
#define TIMER1 111

// Vorw�rtsdeklarationen der in diesem Codemodul enthaltenen Funktionen:
/*ATOM				MyRegisterClass(HINSTANCE hInstance);
BOOL				InitInstance(HINSTANCE, int);
LRESULT CALLBACK	WndProc(HWND, UINT, WPARAM, LPARAM);
LRESULT CALLBACK	About(HWND, UINT, WPARAM, LPARAM);

*/

int APIENTRY WinMain(HINSTANCE hInstance,
	HINSTANCE hPrevInstance,
	LPTSTR    lpCmdLine,
	int       nCmdShow)
{

	
	hInst = hInstance;												//						save in global variable for further use
	// TODO: Hier Code einf�gen.
	MSG msg;
	
	// Globale Zeichenfolgen initialisieren
	LoadString(hInstance, 103, szTitle, MAX_LOADSTRING);
	LoadString(hInstance, 104, szWindowClass, MAX_LOADSTRING);
	//register Window													<<<<<<<<<<			STEP ONE: REGISTER WINDOW						!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	WNDCLASSEX wcex;												//						=> Filling out struct WNDCLASSEX
	BOOL Result = TRUE;
	wcex.cbSize = sizeof(WNDCLASSEX);								//						size of this struct (don't know why
	wcex.style = CS_HREDRAW | CS_VREDRAW;							//						?
	wcex.lpfnWndProc = (WNDPROC)WndProc;							//						The corresponding Proc File -> Message loop switch-case file
	wcex.cbClsExtra = 0;											//
	wcex.cbWndExtra = 0;											//
	wcex.hInstance = hInstance;										//						The number of the program
	wcex.hIcon = LoadIcon(hInstance, NULL);							//
	wcex.hCursor = LoadCursor(NULL, IDC_ARROW);						//
	wcex.hbrBackground = hWinCol;									//						Background color
	wcex.lpszMenuName = NULL;										//
	wcex.lpszClassName = MainWin;									//						Name of the window (must the the same as later when opening the window)
	wcex.hIconSm = LoadIcon(wcex.hInstance, NULL);					//
	Result = (RegisterClassEx(&wcex) != 0);							//						Register this struct in the OS

				//													STEP TWO: OPENING THE WINDOW with x,y position and xlen, ylen !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	hMain = CreateWindow(MainWin, "Arkanoid: The Game", WS_OVERLAPPEDWINDOW | WS_VISIBLE, 250, 100, 800, 600, NULL, NULL, hInst, NULL);
	if (!hMain)return 0;
	ShowWindow(hMain, nCmdShow);
	UpdateWindow(hMain);

	//													STEP THRE: Going into the infinity message loop							  !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

	// Hauptmeldungsschleife:
	bool quit = FALSE;
	while (!quit)
	{
		//if (GetMessage(&msg, NULL, 0, 0) > 0)
		while (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE) == TRUE)
		{
			if (msg.message == WM_QUIT){ quit = TRUE; break; }

			
				TranslateMessage(&msg);								//						IF a meessage occurs, the WinProc will be called!!!!
				DispatchMessage(&msg);
		}
	}
	return (int)msg.wParam;
}
///////////////////////////////////////////////////
void redr_win_full(HWND hwnd, bool erase)
	{
	RECT rt;
	GetClientRect(hwnd, &rt);
	InvalidateRect(hwnd, &rt, erase);
	}

///////////////////////////////////
//		This Function is called every time the Left Mouse Button is down
///////////////////////////////////
void OnLBD(HWND hwnd, BOOL fDoubleClick, int x, int y, UINT keyFlags)
{
	if (counter <= 0)
	{
		counter = 5;
		restart = true;
	}
}
///////////////////////////////////
//		This Function is called every time the Right Mouse Button is down
///////////////////////////////////
void OnRBD(HWND hwnd, BOOL fDoubleClick, int x, int y, UINT keyFlags)
	{
	
	}
///////////////////////////////////
//		This Function is called every time a character key is pressed
///////////////////////////////////
void OnChar(HWND hwnd, UINT ch, int cRepeat)
{

}
///////////////////////////////////
//		This Function is called every time the Left Mouse Button is up
///////////////////////////////////
void OnLBU(HWND hwnd, int x, int y, UINT keyFlags)
{
	restart = false;
	
}
///////////////////////////////////
//		This Function is called every time the Right Mouse Button is up
///////////////////////////////////
void OnRBU(HWND hwnd, int x, int y, UINT keyFlags)
	{
	

	}
///////////////////////////////////
//		This Function is called every time the Mouse Moves
///////////////////////////////////
void OnMM(HWND hwnd, int x, int y, UINT keyFlags)
{
mx = x;
dx = x;
dy = y;

if ((keyFlags & MK_LBUTTON) == MK_LBUTTON)
	{
	}

if ((keyFlags & MK_RBUTTON) == MK_RBUTTON)
	{
	}
}
///////////////////////////////////
//		This Function is called once at the begin of a program
///////////////////////////////////
#define TIMER1 1

BOOL OnCreate(HWND hwnd, CREATESTRUCT FAR* lpCreateStruct)
{
	g_hwnd = hwnd;
	editfont = CreateFont(-10, 0, 0, 0, 0, FALSE, 0, 0, 0, 0, 0, 0, 0, "Arial");	
	if (!SetTimer(hwnd, TIMER1, 20, NULL))
	{
		MessageBox(hwnd, "No Timers Available", "Info", MB_OK);
		return FALSE;
	}
	srand(time(NULL));
	int rand1 = rand() % 100 * 7 + 1;
	
	// Red Brick Layer
	for (int j = 0; j < 2; ++j)
	{
		for (int i = 0; i < 12; ++i)
		{
			Brick* b = new Brick();

			b->width = 50;
			b->height = 15;

			b->x = i * (b->width + 15) + 8;
			b->y = j * (b->height + 2) + 10;
			
			b->r = 255;
			b->g = 0;
			b->b = 0;

			b->exists = true;

			bricks.push_back(b);
		}
	}
	// Green Brick Layer
	for (int j = 2; j < 4; ++j)
	{
		for (int i = 0; i < 12; ++i)
		{
			Brick* b = new Brick();

			b->width = 50;
			b->height = 15;

			b->x = i * (b->width + 15) + 8;
			b->y = j * (b->height + 2) + 10;

			b->r = 0;
			b->g = 255;
			b->b = 0;

			b->exists = true;

			bricks.push_back(b);
		}
	}
	// Blue Brick Layer
	for (int j = 4; j < 6; ++j)
	{
		for (int i = 0; i < 12; ++i)
		{
			Brick* b = new Brick();

			b->width = 50;
			b->height = 15;

			b->x = i * (b->width + 15) + 8;
			b->y = j * (b->height + 2) + 10;

			b->r = 0;
			b->g = 0;
			b->b = 255;

			b->exists = true;

			bricks.push_back(b);
		}
	}
	
	//float angle = ((float)rand()) * 3.14 / 2;  //<-- constants not defined by default
	//ex = cos(angle) * bspeed;

	float angle = 60 * M_PI / 2 ;
	ex = (cos(angle) + sin(angle)) * bspeed;
	ball.x = rand1;
	ball.y = 160;
	ball.dx = ex;
	ball.dy = ex;
	ball.r = 8;

	Paddle* p = new Paddle();

	paddle.x = 400;
	paddle.y = 525;
	paddle.dx = mx;
	paddle.r = 5;

	return TRUE;
}

void OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
	HWND hwin;
	
	switch (id)
	{
	default:
		break;
	}

}
//************************************************************************
void OnTimer(HWND hwnd, UINT id)
{
	redr_win_full(hwnd, FALSE);

	srand(time(NULL));
	int rand1 = rand() % 100 * 8 + 1;

	if (counter >= 1)
	{
		ball.update();
	}
	paddle.update();

	for (int i = 0; i < bricks.size(); ++i)
	{
		if (bricks[i]->exists && bricks[i]->collidesWith(ball)) //<-- short circuit trick
		{
			bricks[i]->exists = false;
			if (bricks[i]->exists != true)
			{
				ball.dy = bspeed;
			}
		}
		if (restart == true)
		{
			bricks[i]->exists = true;
		}
	}

	if (ball.x >= 775)
		ball.dx = -bspeed;
	if (ball.x <= 0)
		ball.dx = bspeed;
	if (ball.y <= 5)
		ball.dy = bspeed;
	if (ball.y >= 550)
	{
		counter--;
		ball.x = rand1;
		ball.y = 160;
	}
	if (ball.x >= (mx - 20) && ball.x <= (mx + 20) && counter >=1)
	{
		if (ball.y >= 520 && ball.y <= 525)
		{
			ball.dy = -bspeed;
		}
	}

}
//************************************************************************
///////////////////////////////////
//		This Function is called every time the window has to be painted again
///////////////////////////////////


void OnPaint(HWND hwnd)
	{

	//if(rglobe.EckSizing.active_sizing())return;
	PAINTSTRUCT PaintStruct;
	HDC DC_ = BeginPaint(hwnd, &PaintStruct);
	HBITMAP hbmMem, hbmOld;
	HDC DC = CreateCompatibleDC(DC_);
	RECT rc;
	GetClientRect(hwnd, &rc);
	hbmMem = CreateCompatibleBitmap(DC_, rc.right - rc.left, 2000);
	hbmOld = (HBITMAP)SelectObject(DC, hbmMem);
	COLORREF bg = RGB(15, 15, 15);
	//if(rglobe.EckSizing.active_sizing())
	//bg=RGB(255,255,0);
	HBRUSH hbrBkGnd = CreateSolidBrush(bg);
	FillRect(DC, &rc, hbrBkGnd);
	DeleteObject(hbrBkGnd);

	//draw here
	for (int i = 0; i < bricks.size(); ++i)
	{
		if(bricks[i]->exists) 
			bricks[i]->draw(DC);
		if (restart == true)
			bricks[i]->draw(DC);		
	}
	if (counter >= 1)
	{
		ball.draw(DC);
	}
	paddle.draw(DC);

	draw_text(DC,"Lives: ", 5, 540, 0, 0, 255);
	if (counter == 5)
	{
		draw_text(DC, "5", 50, 540, 0, 0, 255);
	}
	if (counter == 4)
	{
		draw_text(DC, "4", 50, 540, 0, 0, 255);
	}
	if (counter == 3)
	{
		draw_text(DC, "3", 50, 540, 0, 0, 255);
	}
	if (counter == 2)
	{
		draw_text(DC, "2", 50, 540, 0, 0, 255);
	}
	if (counter == 1)
	{
		draw_text(DC, "1", 50, 540, 255, 0, 0);
	}
	if (counter <= 0)
	{
		draw_text(DC, "0", 50, 540, 255, 0, 0);
		draw_text(DC, "GAME OVER", 350, 300, 255, 0, 0);
		draw_text(DC, "Restart?", 365, 320, 255, 0, 0);
	}

	//end draw here
	//					DOUBLE BUFFERING!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	BitBlt(DC_, rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top, DC, 0, 0, SRCCOPY);
	SelectObject(DC, hbmOld);
	DeleteObject(hbmMem);
	DeleteDC(DC);
	EndPaint(hwnd, &PaintStruct);
	}
//****************************************************************************

void draw_line(HDC DC,int x, int y, int a, int b, int red, int green, int blue, int width)
	{
	HPEN Stift = CreatePen(PS_SOLID, width, RGB(red, green, blue));
	SelectObject(DC, Stift);
	MoveToEx(DC, x, y, NULL);
	LineTo(DC, a, b);
	DeleteObject(Stift);
	}
//*************************************************************************
void OnKeyDown(HWND hwnd, UINT vk, BOOL fDown, int cRepeat, UINT flags)
	{

	switch (vk)
		{
			default:break;
			
		}
	}

//*************************************************************************
void OnKeyUp(HWND hwnd, UINT vk, BOOL fDown, int cRepeat, UINT flags)
	{
	switch (vk)
		{
			default:break;
			
		}

	}


//**************************************************************************
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	int wmId, wmEvent;
	SCROLLINFO si;


	
	switch (message)
	{
	/*
	#define HANDLE_MSG(hwnd, message, fn)    \
    case (message): return HANDLE_##message((hwnd), (wParam), (lParam), (fn))
	*/
		
		HANDLE_MSG(hwnd, WM_CHAR, OnChar);
		HANDLE_MSG(hwnd, WM_LBUTTONDOWN, OnLBD);
		HANDLE_MSG(hwnd, WM_LBUTTONUP, OnLBU);
		HANDLE_MSG(hwnd, WM_MOUSEMOVE, OnMM);	
		HANDLE_MSG(hwnd, WM_CREATE, OnCreate);
		HANDLE_MSG(hwnd, WM_PAINT, OnPaint);
		HANDLE_MSG(hwnd, WM_COMMAND, OnCommand);
		HANDLE_MSG(hwnd, WM_TIMER, OnTimer);
		HANDLE_MSG(hwnd, WM_KEYDOWN, OnKeyDown);
		HANDLE_MSG(hwnd, WM_KEYUP, OnKeyUp);

	case WM_ERASEBKGND:
		return (LRESULT)1;
	case WM_DESTROY:
		
		PostQuitMessage(0);
		break;
	default:
		return DefWindowProc(hwnd, message, wParam, lParam);
	}
	return 0;
}
